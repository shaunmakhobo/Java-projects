
package alist;
import java.util.*;
import java.util.ArrayList;
import java.util.Scanner;


public class AList {

    
    public static void main(String[] args) {
        
        ArrayList<String> STNumber = new ArrayList<String>();
        System.out.println("Please enter student number starting with ST:");
        Scanner UserInput = new Scanner(System.in);
        STNumber.add(UserInput.nextLine());
        
        
    }
    public static void Display(ArrayList<String> STNumber){
        System.out.println(STNumber);
    }
    public static void Loop(ArrayList<String> STNumber) {
        
    }
}
