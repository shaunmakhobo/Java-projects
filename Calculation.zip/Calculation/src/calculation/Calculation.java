
package calculation;


public class Calculation {

    
    public static void main(String[] args) {
       
    }
    
}
