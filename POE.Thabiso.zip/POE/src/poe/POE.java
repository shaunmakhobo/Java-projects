
package poe;


public class POE {

    
    public static void main(String[] args) {
        
        double[] Change = {1.9, 2.9, 3.4, 3.5, 5.5, 10.1};
        System.out.println("List of array is : " + Change[0] + " , " + Change[1] + " , " + Change[2] + " , " + Change[3] + " , " + Change[4]);
        
        double Sum = 0;
       
       for (int i = 0; i < Change.length; i++){
            Sum = Sum + Change[i];
            
            
        }
       System.out.println("Sum of all elements in an array is" + Sum);
       Minimum();
       Maximum();
    }
    public static void Minimum() {
    
        double[] Change = {1.9, 2.9, 3.4, 3.5, 5.5, 10.1};
         double result;
        double min = Change[0];
          if ( Change[1] < min) {
           min = Change[1];
           }
          if ( Change[2] < min) {
           min = Change[2];
          }
          if ( Change[3] < min) {
           min = Change[3];
          }
          if ( Change[4] < min) {
           min = Change[4];
          }
          if ( Change[5] < min) {
           min = Change[5];
          }
         result = min;
         System.out.println("Minimum value is : " + result);
    }
    public static void Maximum() {
    
        double[] Change = {1.9, 2.9, 3.4, 3.5, 5.5, 10.1};
         double result;
        double max = Change[0];
          if ( Change[1] > max) {
           max = Change[1];
           }
          if ( Change[2] > max) {
           max = Change[2];
          }
          if ( Change[3] > max) {
           max = Change[3];
          }
          if ( Change[4] > max) {
           max = Change[4];
          }
          if ( Change[5] > max) {
           max = Change[5];
          }
         result = max;
         System.out.println("Maximum value is : " + result);
    }
}
    

