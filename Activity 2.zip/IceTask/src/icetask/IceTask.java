
package icetask;
import java.util.*;

public class IceTask {

    
    public static void main(String[] args) {
        int[][] Matrix = {{2, 4, 9, 6}, {3, 6, 7, 9}, {4, 8, 6, 1}};
        Column1(Matrix);
        Sum(Matrix);
        Display(Matrix);
        Verse(Matrix);
        DisplaySort1(Matrix);
        DisplaySort2(Matrix);
        DisplaySort3(Matrix);
        Diagonal(Matrix);
    }
    public static void Column1(int[][] Matrix){
     int sum = 0;
        System.out.println("This is the first column: ");
        
            for (int c = 0; c < Matrix.length; c++) {
               sum = sum + Matrix[c][0]; 
                System.out.println(Matrix[c][0]);
            }
         
            System.out.println("This is the sum of the first column: " + sum);
        
    }
    public static void Sum(int[][] Matrix){
          int sum1 = 0;
          for(int c = 0; c < Matrix[0].length; c++){
          sum1 = sum1 + Matrix[0][c];
            

          } 
          System.out.println("Sum of first row is:" + sum1);
          int sum2 = 0;
          for(int c = 0; c < Matrix[1].length; c++){
          sum2 = sum2 + Matrix[1][c];
            

          } 
          System.out.println("Sum of Second row is:" + sum2);
          int sum3 = 0;
          for(int c = 0; c < Matrix[2].length; c++){
          sum3 = sum3 + Matrix[2][c];
            

          } 
          System.out.println("Sum of third row is:" + sum3);
          int Largest = sum1;
          if (sum2 > Largest){
           Largest = sum2;
              System.out.println("Largest Sum is: " + Largest);
          }
          if (sum3 > Largest){
           Largest = sum3;
              System.out.println("Largest Sum is: " + Largest);
          }
        }
   
      public static void Display(int[][] Matrix){
          System.out.println("This is a display of the entire array:");
        for (int r = 0; r < Matrix.length; r++){
         for (int c = 0; c < Matrix[r].length; c++){
             System.out.println(Matrix[r][c]);
         }
        }
      }  
    public static void Verse(int[][] Matrix){
          System.out.println("Row3 in verse: ");
         for (int j = Matrix[2].length -1; j >= 0; j--) {
             System.out.println(Matrix[2][j]); 
         }
     }
    public static void Order1(int[][] Matrix){
        int temp;
    for (int r = 0; r < Matrix.length; r++){
        for (int c = 0; c < Matrix[0].length; c++) {
            for (int i = 0; i < Matrix[0].length -1; i++) {
               if(Matrix[r][i] > Matrix[0][i + 1])
                {
                    temp = Matrix[0][i];
                    Matrix[0][i]= Matrix[0][i + 1];
                    Matrix[0][i + 1] = temp;
                }
            }
           
        }
     
     }
    }
    public static void DisplaySort1(int[][] Matrix){
        Order1(Matrix);
        System.out.println("First row ordered: ");
        for (int i = 0; i < Matrix[0].length; i++) {
            System.out.println(Matrix[0][i]);
        }
    }
    public static void Order2(int[][] Matrix){
        int temp;
    for (int r = 0; r < Matrix.length; r++){
        for (int c = 0; c < Matrix[1].length; c++) {
            for (int i = 0; i < Matrix[1].length -1; i++) {
               if(Matrix[r][i] > Matrix[1][i + 1])
                {
                    temp = Matrix[1][i];
                    Matrix[1][i]= Matrix[1][i + 1];
                    Matrix[1][i + 1] = temp;
                }
            }
           
        }
     
     }
    }
    public static void DisplaySort2(int[][] Matrix){
        Order2(Matrix);
        System.out.println("Second row ordered: ");
        for (int i = 0; i < Matrix[1].length; i++) {
            System.out.println(Matrix[1][i]);
        }
    }
    public static void Order3(int[][] Matrix){
        int temp;
    for (int r = 0; r < Matrix.length; r++){
        for (int c = 0; c < Matrix[0].length; c++) {
            for (int i = 0; i < Matrix[2].length -1; i++) {
               if(Matrix[r][i] > Matrix[2][i + 1])
                {
                    temp = Matrix[2][i];
                    Matrix[2][i]= Matrix[2][i + 1];
                    Matrix[2][i + 1] = temp;
                }
            }
           
        }
     
     }
    }
    public static void DisplaySort3(int[][] Matrix){
        Order3(Matrix);
        System.out.println("Third row ordered: ");
        for (int i = 0; i < Matrix[2].length; i++) {
            System.out.println(Matrix[2][i]);
        }
    }
    public static void Diagonal(int[][] Matrix){
        int Sum = 0;
        System.out.println("Diagonal values: ");
        for (int r = 0; r < Matrix.length; r++) {
        Sum = Sum + Matrix[r][r];
            System.out.println(Matrix[r][r]);
        }
        System.out.println("Sum of Diagonal values is: " + Sum);
    }
    }
    
    

