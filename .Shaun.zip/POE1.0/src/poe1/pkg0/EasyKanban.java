
package poe1.pkg0;

import javax.swing.JOptionPane;


public class EasyKanban {
    static double total;
    static String TASKName = "";
    static int TASKNumber;
    static int defineTASK;
    static String TASKStatus;
    
    public static void showButtons(){
        JOptionPane.showMessageDialog(null, "Welcome to EasyKanban");
        String Task_Numbers;
        int Numtask;
        String TaskName;
        String Task_Description;
        String Developer_Details;
        String Task_Duration;
        int DurationTask;
        String devlName = null;
        int totalHours;
       
     Object[] options = {"Add task",
         "Show report",
         "Quit"};
     int choice =
   JOptionPane.showOptionDialog(null, "Choose an Option:", "Button example", 
           JOptionPane.YES_NO_CANCEL_OPTION,
           JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
     
     //Handle the user's choice 
     while (choice != 2)
             {
     switch (choice){
         case  JOptionPane.YES_OPTION  :  
          Task_Numbers = JOptionPane.showInputDialog(null, "Specify number tasks you want", "First Option", JOptionPane.QUESTION_MESSAGE);
           Numtask = Integer.parseInt(Task_Numbers);
          for (int x = 0; x < Numtask; ++x)
          {
             TaskName = JOptionPane.showInputDialog("Input TaskName");
             Task_Description = JOptionPane.showInputDialog("Input Task Description");
             Task_Duration = JOptionPane.showInputDialog(null, "Input duration in hours");
             DurationTask = Integer.parseInt(Task_Duration);
             
             while (checkTaskDescription(Task_Description) == false )
             { 
             Task_Description = JOptionPane.showInputDialog("Input Task Description");
             

             }
             Developer_Details = JOptionPane.showInputDialog(null, "Input first name and Lastname");
           TaskID(Task_Numbers, TaskName, devlName);

          }
         break;
         
         case  JOptionPane.NO_OPTION:
           JOptionPane.showMessageDialog(null, "Coming Soon");
         break;
         
         case  JOptionPane.CANCEL_OPTION:
       
         break;
         default: 
     }
        choice =
   JOptionPane.showOptionDialog(null, "Choose an Option:", "Button example", 
           JOptionPane.YES_NO_CANCEL_OPTION,
           JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
     }
    }
    public static String TaskID( String Task_Numbers, String Task_Name, String devlName){
        String TaskID = null;
        
        int NumTask;
        NumTask = Integer.parseInt(Task_Numbers);
     
        StringBuilder ID = new StringBuilder(Task_Name);
        ID.setLength(2);
        ID.append(":");
        ID.append(Task_Numbers);
        ID.append(":");
     for (int x = 0;x < devlName.length();++x)
     {  
         if (devlName.charAt(x) == ' ')
         {
         ID.append(devlName.substring(x-3, x));
         String toUpperCase = ID.toString();
         TaskID = toUpperCase.toUpperCase();
         x = devlName.length();
         }
     }
     return TaskID;
    }
    public static boolean checkTaskDescription(String Task_Description ) {
    if (Task_Description.length() > 50){
        return false;
    }
    else {
    return false;
    }
    }
   
    public static String Tststatus(String[] tskStatus, int option) {
        String TempStatus;
    option = JOptionPane.showOptionDialog(null, "Please select an Option", "Add Task", 0, 3, null, tskStatus , tskStatus[0]);
             {
     switch (option){
         case 0:  
          TempStatus = tskStatus[0];
         break;
         
           case 1:
           TempStatus = tskStatus[1];
         break;
         
         case 2:
          TempStatus = tskStatus[2];
         break;
         default:
             TempStatus = "";
     }
      return TempStatus;
     }
    }
    public static String printTaskDetails(String tskName, int tskNum, String taskDescription, int TaskDuration, String TaskID, String TaskStatus) 
        {
        return tskName +"\n"+ tskNum +"\n"+ taskDescription +"\n"+TaskDuration+"hrs"+"\n"+ TaskID+"\n"+ TaskStatus;
        
        } 
        
        public static int returnTotalHours(int totalHours) {
           
           return totalHours;
        }
        }


