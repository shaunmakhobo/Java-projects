
import javax.swing.JOptionPane;
import java.util.Scanner;
import poe1.pkg0.EasyKanban;
import poe1.pkg0.Login;


public class POE10 {

    
    public static void main(String[] args){
        
        
       // String Task_Numbers;
        String username;
        String firstNM, LastNM;
        String pass;
        String fullNM;
        boolean loginStatus = false;
        boolean verifyUserName = false;
        boolean verifyPassword = false;
        int totalHours;
        String tskName;
        int tskNum;
        String taskDescription;
        int TaskDuration;
        String TaskID;
        String TaskStatus;
        
      
        //Login App = new Login();
        
       firstNM = JOptionPane.showInputDialog("Required to input first name");
       LastNM = JOptionPane.showInputDialog("Required to input Last Name");
         
        fullNM = firstNM + " " + LastNM;
        
         
         username = JOptionPane.showInputDialog("Required to input username");
         
          pass = JOptionPane.showInputDialog("Required to input Password");
         
      // Login.checkUserName(username);
       JOptionPane.showMessageDialog(null, Login.checkUserName(username));
        // Login.checkPasswordComplexity(pass);
        JOptionPane.showMessageDialog(null, Login.checkPasswordComplexity(pass));
       // JOptionPane.showMessageDialog(null, Login.registerUser(Login.checkPasswordComplexity(pass), Login.checkUserName(username)));
        for(int c = 1; c < 5 && loginStatus == false; c++)
         { 
             
            loginStatus = Login.loginUser(username, fullNM, pass);
         
           if(loginStatus == true)
            {
               
            //JOptionPane.showMessageDialog(null, Login.returnLoginStatus(loginStatus, fullNM));
             c = 6;
            }
          // else
            {
            // JOptionPane.showMessageDialog(null, Login.returnLoginStatus(loginStatus, fullNM));
                    
            }
            
             
       // Login.registerUser(true, true);
        //JOptionPane.showMessageDialog(null, Login.registerUser(true, true));
       //Login.returnLoginStatus(username, pass);
        }
        JOptionPane.showMessageDialog(null, Login.returnLoginStatus(loginStatus, fullNM));
        EasyKanban.showButtons();
        EasyKanban.TaskID(LastNM, username, username);
        EasyKanban.checkTaskDescription( Task_Description);
        EasyKanban.Tststatus(tskStatus, option);
        EasyKanban.printTaskDetails(tskName, tskNum, taskDescription, TaskDuration, TaskID, TaskStatus);
        EasyKanban.returnTotalHours(totalHours);
        
        JOptionPane.showMessageDialog(null, EasyKanban.TaskID(LastNM, username, username));
               
         
       
                    
        }   
}

