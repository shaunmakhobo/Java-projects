
package classactivity;

import java.util.Scanner;
import javax.swing.JOptionPane;


public class ClassActivity {

    
    public static void main(String[] args) {
        Scanner myObj = new Scanner(System.in);
    int[][] myList = {{3,4,7,8},{10,20,41,70},{30,40,2,5}};
        System.out.println("Please enter number you wish to search:");
        int Number = myObj.nextInt();
    for (int r = 0; r < myList.length; r++){
      for (int c = 0; c <myList[r].length; c++){
        if (myList[r][c] == Number)
        { System.out.println("Number found: " + Number);}
     
              
      } 
    }
     
    }  
}
