
package ices.task.pkg4;

import java.util.Random;
import java.util.Scanner;


public class IcesTask4 {

   
    public static void main(String[] args) {
       Random random = new Random();
        Scanner input = new Scanner(System.in);
        int operand1;
        int operand2;
        int correctResult;
        boolean check = true;
        int result;
        
        //Genarate two random integers between 0 and 100
        operand1 = random.nextInt(101);
        operand2 = random.nextInt(101);
        
        // Perform the binary operation (addition in this case)
        correctResult = operand1 + operand2;
        
        //prompting user to enter the result of the operation
        System.out.println("Solve the following problem:");
        System.out.println(operand1 + " + " + operand2 + " = ?");

        while(check)
        {
            System.out.print("Enter your answer: ");
            result = input.nextInt();
            
            //checking if user's answer is correct
            if(result == correctResult)
            {
                System.out.println("Correct! well done.");
                check = false;
            }
            else
            {
                System.out.println("Incorrect. Please try again.");
                check = true;
            }
        }
        
        System.out.println("Thank you for participating.");
        
        // Close the scanner
        input.close();
    }
    
}
