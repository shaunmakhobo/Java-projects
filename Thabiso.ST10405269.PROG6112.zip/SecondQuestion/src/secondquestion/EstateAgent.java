
package secondquestion;


public class EstateAgent implements iEstateAgent{
  private String Name;
  private double Price;
  private double commission;
    public EstateAgent(String Name, double Price) {
        this.Name = Name;
        this.Price = Price;
    }

    public String getAgentName() {
        return Name;
    }

    public double getPropertyPrice() {
        return Price;
    }

    public double getAgentCommission() {
        commission = Price * 0.2;
        return commission;
    }
  
  
}
