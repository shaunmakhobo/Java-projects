
package secondquestion;

import java.util.Scanner;


public class SecondQuestion {

    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the current estate agent name: ");
        String UserName = input.nextLine();
        System.out.print("Enter the property price: ");
        double UserPrice = input.nextDouble();
        EstateAgentSales Storage = new EstateAgentSales(UserName, UserPrice);
        Storage.printPropertyReport();
    }
    
}
