
package secondquestion;


public class EstateAgentSales extends EstateAgent{

    public EstateAgentSales(String Name, double Price) {
        super(Name, Price);
    }
    
    public void printPropertyReport()
    {
        System.out.println("ESTATE AGENT REPORT");
        System.out.println("***************************");
        System.out.println("ESTATE AGENT NAME: " + getAgentName());
        System.out.println("PROPERT PRICE: " + getPropertyPrice());
        System.out.println("AGENT COMMISSION: " + getAgentCommission());
    }
}
