
package takehomeexam;



public class TakeHomeExam {

    public static void main(String[] args) {
        
        
       String[] CameraMod = {"CANON", "SONY", "NIKON"};
       String[][] Table = {{"       ", "MIRRORLESS"," ", "DSLR"},
                           {CameraMod[0],"  R", "10500.00","     R", "8500.00"}, 
                           {CameraMod[1],"   R", "9500.00","      R", "7200.00"}, 
                           {CameraMod[2],"  R", "12000.00","     R", "8000.00"}};
        System.out.println("CAMERA TECHNOLOGY REPORT");
        System.out.println("           ");
       for (int r = 0; r < Table.length; r++) {
         for (int c = 0; c < Table[r].length; c++) {
          System.out.print(Table[r][c]);
            }
            System.out.println();
        }
        System.out.println("              ");
        System.out.println("CAMERA TECHNOLOGY RESULTS");
      
       double Price1 = Double.parseDouble(Table[1][2]);
       double Price2 = Double.parseDouble(Table[1][4]);
       double Price3 = Double.parseDouble(Table[2][2]);
       double Price4 = Double.parseDouble(Table[2][4]);
       double Price5 = Double.parseDouble(Table[3][2]);
       double Price6 = Double.parseDouble(Table[3][4]);
       
      
      double Difference1 =  Price1 - Price2;
       // System.out.println(Difference1);
        
      double Difference2 =  Price3 - Price4;
       // System.out.println(Difference2);
        
      double Difference3 =  Price5 - Price6;
       // System.out.println(Difference3);
       
     String TOTAL1 = String.valueOf(Difference1);
     String TOTAL2 = String.valueOf(Difference2);
     String TOTAL3 = String.valueOf(Difference3);
     
     double[] PriceList = {Difference1, Difference2, Difference3};
     
     String [][] Results = {{CameraMod[0],"  R", TOTAL1}, 
                            {CameraMod[1],"   R", TOTAL2}, 
                            {CameraMod[2],"  R", TOTAL3, "  ***"}};
     
        for (int r = 0; r < Results.length; r++) {
            for (int c = 0; c < Results[r].length; c++) {
                System.out.print(Results[r][c]);  
            }
            System.out.println();   
            
        }
        double[] Comparism = {Difference1, Difference2, Difference3};
        double TempDifference = PriceList[0];
        String TempCamMod = CameraMod[0];
        
        
        
        for (int i = 1; i < Comparism.length; i++) {
           if (PriceList[i] > TempDifference){
               TempCamMod = CameraMod[i];
               
           }
        }
        System.out.println("CAMERA WITH THE MOST COST DIFFERENCE: "+  TempCamMod);
    }
    }
    

