
package asignment1;

import java.util.ArrayList;
import java.util.Scanner;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class Asignment1IT {
    
    public Asignment1IT() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of main method, of class Asignment1.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Asignment1.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of Capture method, of class Asignment1.
     */
    @Test
    public void testCapture() {
        System.out.println("Capture");
        ArrayList<String> StudentName = null;
        ArrayList<Integer> StudentId = null;
        ArrayList<Integer> StudentAge = null;
        ArrayList<String> StudentEmail = null;
        ArrayList<String> StudentCourse = null;
        Scanner UserInput = null;
        Asignment1.Capture(StudentName, StudentId, StudentAge, StudentEmail, StudentCourse, UserInput);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of Display method, of class Asignment1.
     */
    @Test
    public void testDisplay() {
        System.out.println("Display");
        ArrayList<String> StudentName = null;
        ArrayList<Integer> StudentId = null;
        ArrayList<Integer> StudentAge = null;
        ArrayList<String> StudentEmail = null;
        ArrayList<String> StudentCourse = null;
        Scanner UserInput = null;
        Asignment1.Display(StudentName, StudentId, StudentAge, StudentEmail, StudentCourse, UserInput);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of Search method, of class Asignment1.
     */
    @Test
    public void testSearch() {
        System.out.println("Search");
        ArrayList<String> StudentName = null;
        ArrayList<Integer> StudentId = null;
        ArrayList<Integer> StudentAge = null;
        ArrayList<String> StudentEmail = null;
        ArrayList<String> StudentCourse = null;
        Scanner UserInput = null;
        Asignment1.Search(StudentName, StudentId, StudentAge, StudentEmail, StudentCourse, UserInput);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of Store method, of class Asignment1.
     */
    @Test
    public void testStore() {
        System.out.println("Store");
        ArrayList<String> StudentName = null;
        ArrayList<Integer> StudentId = null;
        ArrayList<Integer> StudentAge = null;
        ArrayList<String> StudentEmail = null;
        ArrayList<String> StudentCourse = null;
        Scanner UserInput = null;
        Asignment1.Store(StudentName, StudentId, StudentAge, StudentEmail, StudentCourse, UserInput);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of Delete method, of class Asignment1.
     */
    @Test
    public void testDelete() {
        System.out.println("Delete");
        ArrayList<String> StudentName = null;
        ArrayList<Integer> StudentId = null;
        ArrayList<Integer> StudentAge = null;
        ArrayList<String> StudentEmail = null;
        ArrayList<String> StudentCourse = null;
        Scanner UserInput = null;
        Asignment1.Delete(StudentName, StudentId, StudentAge, StudentEmail, StudentCourse, UserInput);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
