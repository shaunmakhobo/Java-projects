
package ice.task.pkg2;

import java.util.Scanner;


public class IceTask2 {

    
    public static void main(String[] args) {
        
        //Declaration
        String name;
        String surname;
        int age;
        String maritalStatus;
        String location;
        String institution;
        double balance;
        String color;
        String initials;
        int firstNumber;
        int secondNumber;
        int results;
        int increment;
        double quotation;
        
        Scanner input = new Scanner(System.in);
        
        try{
        //prompting the user
        System.out.print("Enter your name: ");
        name = input.next();
        System.out.print("Enter your surname: ");
        surname = input.next();
        System.out.print("Enter your age: ");
        age = input.nextInt();
        System.out.print("Enter your marital status: ");
        maritalStatus = input.next();
        System.out.print("Enter your location: ");
        location = input.next();
        System.out.print("Enter the name of the institution you are enrolled at: ");
        institution = input.next();
        System.out.print("Enter your bank balance: ");
        balance = input.nextDouble();
        System.out.print("Enter your favourite color: ");
        color = input.next();
        System.out.print("Enter your initials: ");
        initials = input.next();
        System.out.print("Enter first number to sum: ");
        firstNumber = input.nextInt();
        System.out.print("Enter second number to sum with first number: ");
        secondNumber = input.nextInt();
        System.out.println("------------------------------------------------------------");
        
        //Calculating the sum 
        results = firstNumber + secondNumber;
        increment = firstNumber + 1;
        quotation = secondNumber / firstNumber;
        
        //Displaying final output
        System.out.println("-----------------------------------------------------------");
        System.out.println("DISPLAY OF ALL INFORMATION");
        System.out.println("-----------------------------------------------------------");
        System.out.println("Your name is " + name);
        System.out.println("Your surname is " + surname);
        System.out.println("You are " + age + "years old");
        System.out.println("Your marital status is: " + maritalStatus);
        System.out.println("Your location is: " + location);
        System.out.println("The name of the institution enrolled at: " + institution);
        System.out.println("Your bank balance is R: " + balance);
        System.out.println("Your favorite color: " + color);
        System.out.println("Your initials are: " + initials);
        System.out.println("The sum of " + firstNumber + "+" + secondNumber + " = " + results);
        System.out.println("The first number added by 1 is  " + firstNumber + " + 1 = " + increment);
        System.out.println("The devision of the second number is " + secondNumber +" / "+firstNumber + "=" + quotation);
        System.out.println("------------------------------------------------------------");
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
    }
    
}
