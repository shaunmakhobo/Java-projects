
package activity3;


public class Activity3 {

    
    public static void main(String[] args) {
        
        String[][] pattern = {{" "," "," ","J"," "," "," "," ","A"},
                              {" "," "," ","J"," "," "," ","A"," ","A"},
                              {"J"," "," ","J"," "," ","A","A","A","A","A"},
                              {" ","J","J"," "," ","A"," "," "," "," "," ","A"}};
        for (int r = 0; r < pattern.length; r++) {
            for (int c = 0; c < pattern[r].length; c++) {
                System.out.println(pattern[r][c]);
            }
 
        }
    }
    
}
