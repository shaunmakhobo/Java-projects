
package squickyclean;

import javax.swing.JOptionPane;


public class Vehicle {
    private String[] cars = {"Minibus","SUV","Sedan","Hatchback"};
    //This string is to know what type of car the user selected
    private String vehicle;
    private final double[] carPrices = {100,80,70,60};
    private final int[] washTimes = {60,50,40,30};
    //This is to find out how much time the user
    private int washDuration;
    private double Price;
    //private int decision;
    private final double valetPrice = 20;
    //This will give us info if the user wants valet washing
    private String valet;
    //private int xtraDecisions;

    public Vehicle(int decision, int xtraDecisions) {
        decision = JOptionPane.showOptionDialog(null, "What type of car do you have?", "Squicky Clean", 0, JOptionPane.QUESTION_MESSAGE, null, cars, null);
        vehicle = cars[decision];
        Price = carPrices[decision];
        washDuration = washTimes[decision];
        xtraDecisions = JOptionPane.showConfirmDialog(null, "Would you like to include valet washing ?", "Squicky Clean", JOptionPane.YES_NO_OPTION);
       // Test messege
       // System.out.println("xtraDecisions is " + xtraDecisions);
        
        if(xtraDecisions == JOptionPane.YES_OPTION)
        {
            Price = Price + valetPrice;
            valet = "Yes";
        }
        else
        {
            valet = "No";
        }
        
    }

   public int getDuration() {
      return washDuration;
   }

    public double getPrice() {
        return Price;
    }

    public String getVehicle() {
        return vehicle;
    }
      
      
       public int[] getWashTimes(){
           return washTimes;
       }
       public double[] getCarPrices(){
           return carPrices;
       }
       public double getValetPrice(){
           return valetPrice;
       }

    public String getValet() {
        return valet;
    }

    
}
