
package squickyclean;

import javax.swing.JOptionPane;

public class Wash extends Vehicle { 
    
    private final int HalfWash = 2;
    private int duration;
    private String[] washType = {"Exterior only","Interior Cleaning", "Both interior and exterior"};
    private String wash;
    private int[] washPrice;
    private final int polishCost = 15;
    private double Price;
    private int washDuration;
    
    public Wash(int decision, int xtraDecisions, int response) {
        super(decision, xtraDecisions);
       response = JOptionPane.showInternalOptionDialog(null,  "Choose prefered was method", "Washing method type", 0, JOptionPane.YES_NO_CANCEL_OPTION, null, washType, washType[2]);
       switch (response)
       {
           case JOptionPane.YES_OPTION :
              Price = super.getPrice()/HalfWash  ;
              washDuration = (int) (super.getDuration()/1.5) ;
              wash = washType[0];
           break;
           case JOptionPane.NO_OPTION :
            Price = super.getPrice()/HalfWash;
            washDuration = (int) (super.getDuration()/1.5) ;
            wash = washType[1];
           break;
           case JOptionPane.CANCEL_OPTION :
             Price = super.getPrice() ;
             wash = washType[2];
             washDuration = (int) (super.getDuration());
           break;
               default:
       }
                

  
    }
    
    public void diaplay(){
        JOptionPane.showMessageDialog(null, "Car: \t" + getVehicle() + "\n" +
                                                        "Valet Washing: \t" + getValet() + "\n" +
                                                        "Type of Wash: \t" + wash + "\n" +
                                                        "Duration: \t" + washDuration + " min" + "\n" +
                                                        "\n" +
                                                        "Total: \tR" + Price, "Squicky Clean", JOptionPane.INFORMATION_MESSAGE);
 
}
    
}
