
package squickyclean;

import javax.swing.JOptionPane;


public class SquickyClean {

    
    public static void main(String[] args) 
    {
        int answer = 1;
        int Continue = 0;
        int desition = 0,extraDecition = 0,response = 0;
      
            Wash value= new Wash(desition, extraDecition, response);
            value.diaplay();
            //Continue = JOptionPane.showConfirmDialog(null, "Would you like to continue ?", "Squicky Clean", JOptionPane.YES_NO_OPTION);
    
       System.out.println("Goodbye");
       System.exit(0);
       
    }
    
    
}
