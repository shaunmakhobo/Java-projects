/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package asignment1;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author shaun chaos
 */
public class StudentInfo extends Asignment1{
  public static void Display(ArrayList<String> StudentName, ArrayList<Integer> StudentId, ArrayList<Integer> StudentAge, ArrayList<String> StudentEmail, ArrayList<String> StudentCourse, Scanner UserInput)
   {
   for (int i = 0; i < StudentId.size(); i++) {
              System.out.println("---------------------------------------------");
               System.out.println("Student " + (i+1));
               System.out.println("---------------------------------------------");
                System.out.println("STUDENT ID: "+ StudentId.get(i));
                System.out.println("STUDENT NAME: "+ StudentName.get(i));
                System.out.println("STUDENT AGE: "+ StudentAge.get(i));
                System.out.println("STUDENT EMAIL: "+ StudentEmail.get(i));
                System.out.println("STUDENT COURSE: "+ StudentCourse.get(i));
           }
   }
   public static void Search(ArrayList<String> StudentName, ArrayList<Integer> StudentId, ArrayList<Integer> StudentAge, ArrayList<String> StudentEmail, ArrayList<String> StudentCourse, Scanner UserInput)
   {
   
         System.out.println("Enter the student id to search: ");
         int search = 0;
        search = UserInput.nextInt();
           for (int i = 0; i < StudentId.size(); i++) {
              
   
   // Here you must input the id
   
   // loop through the arrayList 
   
   // check if the id exists 
   
   // if the id exists then ouput the Id Information
   
   // Else Go back to the prompt
   
            if(search == StudentId.get(i))
            {
               System.out.println("Student ID: " + StudentId.get(i));
               System.out.println("Student Name: " + StudentName.get(i));
               System.out.println("Student Age: " + StudentAge.get(i));
               System.out.println("Student Email: " + StudentEmail.get(i));
               System.out.println("Student Course: " + StudentCourse.get(i));
               i = StudentId.get(i);
            }
            else
            {
                if (search != (StudentId.size()-1) && i == StudentId.size())
                System.out.println("Student with Student Id:" + search + "was not found");
            } 
            
           }
   }
   public static void Store(ArrayList<String> StudentName, ArrayList<Integer> StudentId, ArrayList<Integer> StudentAge, ArrayList<String> StudentEmail, ArrayList<String> StudentCourse, Scanner UserInput)
   {
   for (int i = 0; i < 1; i++) {
               
     System.out.println("Enter the student Id: ");
     StudentId.add(i, UserInput.nextInt());
     
     
     System.out.println("Enter the student Age: ");
     StudentAge.add(i,UserInput.nextInt());
     while (StudentAge.get(i) < 16)
     {
     System.out.println("You have entered an incorrect student age!!!");
         System.out.println("Please re-enter the student age >> ");
     StudentAge.add(i,UserInput.nextInt());
     }
     
         
     System.out.println("Enter the student Email: ");
     StudentEmail.add(i,UserInput.next());
     
     
     System.out.println("Enter the student Course: ");
     StudentCourse.add(i,UserInput.next());
     
     System.out.println("Enter the student Name: ");
     StudentName.add(i,UserInput.next());
     
        System.out.println("The Student details have been successfully saved");
           }
   }
   public static void Delete(ArrayList<String> StudentName, ArrayList<Integer> StudentId, ArrayList<Integer> StudentAge, ArrayList<String> StudentEmail, ArrayList<String> StudentCourse, Scanner UserInput)
   {
   String Yes = "y";
           String Response;
           int count = 0;
            System.out.println("Please enter student id: ");
           int Stcout;
           Stcout = UserInput.nextInt();
          for (int i = 0; i < StudentId.size(); i++) {
             
            if(Stcout == StudentId.get(i))
            {
            
                System.out.println("Are you sure you want to delete student"+ StudentId.get(i) + "from the system? Yes (y) to delete.");
                Response = UserInput.next();
                
                if(Response.equalsIgnoreCase(Yes))
                {
                System.out.println("Student with Student Id:" + StudentId.get(i) + "Was Deleted!");
                StudentId.remove(i);
                StudentAge.remove(i);
                StudentCourse.remove(i);
                StudentName.remove(i);
                StudentEmail.remove(i);
                   i = StudentId.size();  
                }
               
            }
            else
            {
                if (Stcout  != (StudentId.size()-1) && i == StudentId.size())
                System.out.println("Student does not exist");
            } 
           }
   }   
}
