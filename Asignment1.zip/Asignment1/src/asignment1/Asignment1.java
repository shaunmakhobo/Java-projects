
package asignment1;

import java.util.ArrayList;
import java.util.Scanner;


public class Asignment1 {

    
    public static void main(String[] args) {
        ArrayList<String> StudentName   = new ArrayList<>();
        ArrayList<Integer> StudentId    = new ArrayList<>();
        ArrayList<Integer> StudentAge   = new ArrayList<>();
        ArrayList<String> StudentEmail  = new ArrayList<>();
        ArrayList<String> StudentCourse = new ArrayList<>();
        
        
        
     int Enter = 1;
     int Input;
        Scanner UserInput = new Scanner(System.in);
        System.out.println("Enter " + Enter + " to launch menu or any other key to exit");
        Input = UserInput.nextInt();
       
     while (Input == Enter)
     {
         Capture(StudentName, StudentId, StudentAge, StudentEmail, StudentCourse, UserInput, Input);
         System.out.println("Enter " + Enter + " to launch menu or any other key to exit");
         Input = UserInput.nextInt();
     }
    }
    public static void Capture(ArrayList<String> StudentName, ArrayList<Integer> StudentId, ArrayList<Integer> StudentAge, ArrayList<String> StudentEmail, ArrayList<String> StudentCourse, Scanner UserInput, int input)
    {
        StudentInfo Attendants = new StudentInfo();
        
        System.out.println("Please select one of the following menu items:");  
        System.out.println("(1) Capture a new student.");
        System.out.println("(2) Search for a student.");
        System.out.println("(3) Delete a student.");
        System.out.println("(4) Print student report.");
        System.out.println("(5) Exit Application.");
        int Select = UserInput.nextInt();
    
   switch (Select){
       case 1:
           Attendants.Store(StudentName, StudentId, StudentAge, StudentEmail, StudentCourse, UserInput);
     break;
       case 2: 
           Attendants.Search(StudentName, StudentId, StudentAge, StudentEmail, StudentCourse, UserInput);
     break;
       case 3:
           Attendants.Delete(StudentName, StudentId, StudentAge, StudentEmail, StudentCourse, UserInput);
           break;
       case 4:
           Attendants.Display(StudentName, StudentId, StudentAge, StudentEmail, StudentCourse, UserInput);
           break;
       case 5: 
             System.exit(0);
      break;
       default:
   }
   
    }
  
}
