
package ice.task5;

import java.util.Scanner;


public class IceTask5 
{

    
    public static void main(String[] args) 
    {
       Scanner scanner = new Scanner(System.in);
        Student[] students = new Student[3];

        // Prompt the user to enter information for three students
        for (int i = 0; i < 3; i++) {
            System.out.println("Enter details for student " + (i + 1) + ":");

            System.out.print("ID: ");
            int id = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            System.out.print("Name: ");
            String name = scanner.nextLine();

            System.out.print("Age: ");
            int age = scanner.nextInt();

            System.out.print("Grade: ");
            char grade = scanner.next().charAt(0);

            // Create Student object
            students[i] = new Student(id, name, age, grade);
            System.out.println();
        }

        // Display the details of each student
        System.out.println("Details of all students:");
        for (Student student : students) {
            student.displayDetails();
            System.out.println();
        }

        // Update the grade of a student based on user input
        System.out.print("Enter the ID of the student whose grade you want to update: ");
        int updateId = scanner.nextInt();
        boolean studentFound = false;

        for (Student student : students) {
            if (student.getId() == updateId) {
                System.out.print("Enter new grade for " + student.getName() + ": ");
                char newGrade = scanner.next().charAt(0);
                student.updateGrade(newGrade);
                studentFound = true;
                System.out.println("Grade updated successfully.");
                System.out.println();

                // Display the updated details of the student
                System.out.println("Updated details of the student:");
                student.displayDetails();
                break;
            }
        }

        if (!studentFound) {
            System.out.println("Student with ID " + updateId + " not found.");
        }

        // Close the scanner
        scanner.close();
       
    }
    
}
