/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ice.task5;

/**
 *
 * @author Shaun Makhobo
 */
public class Student 
{
  // Attributes
    private int id;
    private String name;
    private int age;
    private char grade;

    // Parameterized constructor
    public Student(int id, String name, int age, char grade) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.grade = grade;
    }

    // Method to display student details
    public void displayDetails() {
        System.out.println("ID: " + id);
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Grade: " + grade);
    }

    // Method to update the grade of a student
    public void updateGrade(char newGrade) {
        this.grade = newGrade;
    }

    // Getters for ID and Name for ease of identification during updates
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}
