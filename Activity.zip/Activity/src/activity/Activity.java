
package activity;

import java.util.Scanner;


public class Activity {

    
    public static void main(String[] args) {
       /* int number = 35;
        String score = String.format("%d", number);
        System.out.println(score);*/
    int[] Task_Marks = {97, 85, 90, 69};
     
     for (int i = 0; i < Task_Marks.length; i++)
         
   
     System.out.println(Task_Marks[i]);
    }
    
    
    
}
