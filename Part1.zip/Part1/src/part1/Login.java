package part1;

import javax.swing.JOptionPane;

public class Login {
  
    public static boolean checkUserName(String Username){
        
       if (Username.length() <= 5 && Username.contains("_") )
       {
    JOptionPane.showMessageDialog(null, "Username successfully captured");
         return true;
         
       }else{
    JOptionPane.showMessageDialog(null, "Username incorrectly formated" + "please Ensure that your username contains an underscore " + 
                     "and is not longer than 5 characters in length ");
                  return false;
             
         
                  
 }
      
    } 
    public static boolean checkPasswordComplexity(String Password, String upperCase, String lowerCase, String numbers, String charcters){
     if ( Password.length() >= 8 
            && Password.matches(charcters)
            && Password.matches(upperCase)
            && Password.matches(lowerCase)
            && Password.matches(numbers))
       {  
           JOptionPane.showMessageDialog(null, "password successfully captured");
           return true;
       }  
        else 
   {
  JOptionPane.showMessageDialog(null, "Password is not correctly formatted please ensure that "
          + " the password contains at least 8 characters, a capital letter, a number and a special character.");
        return false;      
 
}
        
    }
   public static String registerUser(boolean checkpassword, boolean checkUsername){
   if (checkUsername==true && checkpassword==true ){
       return "The two conditions have been met and the user has been resgistered successfully";
     } else {
      return "The username or password is incorrectly formated";
  }
        
   } 
   public static Boolean loginUser(String Username, String fullName, String Password){
   String Usern = JOptionPane.showInputDialog("Kindly Login with registered Username");
    String PassWd = JOptionPane.showInputDialog("Kindly Login with registered Password");

    
if (Usern.equals(Username) && PassWd.equals(Password)){
    return true;
   
    } 
else 
    {
    return false;
    }
   }
   public static String returnLoginStatus(String fullName, boolean checkLogin){
   String a = "Welcome " + fullName + " it is great to see you again";
   String b = "Username or password incorrect please try again";
   
   if (checkLogin == true)
       {
        JOptionPane.showMessageDialog(null, "A successful login");
               
        return a;
     } 
     else 
     {
        JOptionPane.showMessageDialog(null, "A failed login");
        return b;
     }   
   }  
}
