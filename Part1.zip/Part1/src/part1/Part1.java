
package part1;

import javax.swing.JOptionPane;
import static part1.Login.checkPasswordComplexity;
import static part1.Login.checkUserName;
import static part1.Login.loginUser;
import static part1.Login.registerUser;
import static part1.Login.returnLoginStatus;


public class Part1 {

    private static String firstName;
    private static String userName;
    private static String password;
    private static String lastName;
    private static String fullName;
    
    public static void main(String[] args) {
     String FirstName;
     String LastName;
     String Password;
     String Username;
     String upperCase = "(.*[A-Z].*)";
     String lowerCase = "(.*[a-z].*)";
     String numbers = "(.*[0-9].*)";
     String charcters = "(.*[@,#,$,%].*)";
     boolean loginStatus = false;
    
     Login App = new Login();
     
     firstName = JOptionPane.showInputDialog(null, "Please enter First Name");
       FirstName = firstName;
      
       lastName = JOptionPane.showInputDialog(null, "Please Enter Last Name");
       LastName = lastName;
       
       fullName = FirstName + " " + LastName;
       
       userName = JOptionPane.showInputDialog(null, "Please enter username");
       Username = userName;
       
       password = JOptionPane.showInputDialog(null, "Please Enter password");
       Password = password;
       
       // JOptionPane.showMessageDialog(null, Login.checkUserName(Username));
       // JOptionPane.showMessageDialog(null, Login.checkPasswordComplexity(Password, upperCase, lowerCase, numbers, charcters));
         
                
            
        if(checkUserName(Username) == false && checkPasswordComplexity(Password, upperCase, lowerCase, numbers, charcters) == false )
        {
         JOptionPane.showMessageDialog(null, registerUser(false, false));            
          for (int b = 0; b < 5 ; b++) 
          { 
              userName = JOptionPane.showInputDialog(null, "Please enter username");
       Username = userName;
       
       password = JOptionPane.showInputDialog(null, "Please Enter password");
       Password = password;
              b = 6;
          }
          }
        else 
        {
            JOptionPane.showMessageDialog(null, registerUser(true, true));    
            
        }
         
        for (int c = 0; c < 5 && loginStatus == false; c++)
        {
        loginStatus = loginUser(Username, fullName, Password);
        
        if(loginStatus == true)
        {
        
            JOptionPane.showMessageDialog(null, returnLoginStatus(fullName, loginStatus));
            c = 6;
        }
        else
        {
        
            JOptionPane.showMessageDialog(null, returnLoginStatus(fullName, loginStatus));
        }
        }
 
    }
    
}
