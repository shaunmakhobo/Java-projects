package first_question;


public class EstateAgent extends FirstQuestion {
    public static void EstateAgentSales(double[][] propertySales, double sum1, double sum2){
        //Loop through 2D array to calculate sum of property sales
        for (int months = 0; months < propertySales.length; months++) {
            for (int agents = 0; agents < propertySales[months].length; agents++) {
                
             sum1 =propertySales[0][0] + propertySales[0][1] + propertySales[0][2]; 
             sum2 =propertySales[1][0] + propertySales[1][1] + propertySales[1][2];
               
            }
        } 
         System.out.println("Total property sales for Joe Bloggs = R" + sum1);
         System.out.println("Total property sales for Jane Doe = R" + sum2);
    }
    public static void EstateAgentCommission(double[][] propertySales, double commission, double sum1, double sum2, double firstCommission, double secondCommission)
    {
      
      for (int months = 0; months < propertySales.length; months++) {
            for (int agents = 0; agents < propertySales[months].length; agents++) {
                
            sum1 =propertySales[0][0] + propertySales[0][1] + propertySales[0][2]; 
             sum2 =propertySales[1][0] + propertySales[1][1] + propertySales[1][2];
              
             
             //calculate commission
             firstCommission  = sum1 * commission; 
             secondCommission =sum2 * commission;
                
            }
        }
      System.out.println("Sales commission for Joe Bloggs = R" + firstCommission);
      System.out.println("Sales commission for Jane Doe = R" + secondCommission);
    }
    public static void TopEstateAgent(double[][] propertySales, double commission,double totalSales,double firstCommission, double secondCommission,double sum1,double sum2){
        
         for (int months = 0; months < propertySales.length; months++) {
            for (int agents = 0; agents < propertySales[months].length; agents++) {
             sum1 =propertySales[0][0] + propertySales[0][1] + propertySales[0][2]; 
             sum2 =propertySales[1][0] + propertySales[1][1] + propertySales[1][2];
               
             firstCommission  = sum1 * commission; 
             secondCommission =sum2 * commission;
            
            }
        }   
            //return Top perfoming estate agent
             if (secondCommission > firstCommission)
             {
             
              System.out.println("Top perfoming estate agent : Joe Bloggs" );
             }
             else 
             {
              System.out.println("Top perfoming estate agent : Jane Doe" );
             } 
    }
    
}
