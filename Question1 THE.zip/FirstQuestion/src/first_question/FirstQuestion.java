
package first_question;



public class FirstQuestion {

    
    public static void main(String[] args) {
        
      double sum1 = 0;
      double sum2 = 1;
      
      double firstCommission = 0;
      double secondCommission = 0;
        
       double[][] propertySales = {{800000.0, 1500000.0, 2000000.0},
                                   {700000.0, 1200000.0, 1600000.0}}; 
       
       final double commission = 0.02; // Commission earned by estate agent.
       
       double totalSales = 0;
       
       
       
        System.out.println("ESTATE AGENT SALES REPORT");
        System.out.println("                                     ");
        System.out.println("              " + "JAN"+ "                 "+ "FEB"+ "                 "+ "MAR");
        System.out.println("---------------------------------------------------------------------------------------------------------------");
         for (int month = 0; month < propertySales.length; month++) {
            for (int agent = 0; agent < propertySales[month].length; agent++) {
                
                   
            }
         }
         System.out.println("Joe Bloggs "+ "        R" + propertySales[0][0]+ "        R" + propertySales[0][1]+ "        R" + propertySales[0][2]);
         System.out.println("Jane Doe "+ "        R" + propertySales[1][0]+ "        R" + propertySales[1][1]+ "        R" + propertySales[1][2]);
                
         System.out.println("                                                                                                                       ");
        EstateAgent.EstateAgentSales(propertySales, sum1, sum2);
        System.out.println("                                                                                                              ");
        EstateAgent.EstateAgentCommission(propertySales, commission, sum1, sum2, firstCommission, secondCommission);
        System.out.println("                                                                                                                    ");
        EstateAgent.TopEstateAgent(propertySales, commission, totalSales, firstCommission, secondCommission, sum1, sum2);
        
        
       
    }
    
}
