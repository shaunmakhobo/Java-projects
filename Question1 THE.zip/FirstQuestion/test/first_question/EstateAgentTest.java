/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package first_question;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author shaun chaos
 */
public class EstateAgentTest {
    
    public EstateAgentTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of EstateAgentSales method, of class EstateAgent.
     */
    @Test
    public void testEstateAgentSales() {
        System.out.println("EstateAgentSales");
        double[][] propertySales = null;
        double sum1 = 0.0;
        double sum2 = 0.0;
        EstateAgent.EstateAgentSales(propertySales, sum1, sum2);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of EstateAgentCommission method, of class EstateAgent.
     */
    @Test
    public void testEstateAgentCommission() {
        System.out.println("EstateAgentCommission");
        double[][] propertySales = null;
        double commission = 0.0;
        double sum1 = 0.0;
        double sum2 = 0.0;
        double firstCommission = 0.0;
        double secondCommission = 0.0;
        EstateAgent.EstateAgentCommission(propertySales, commission, sum1, sum2, firstCommission, secondCommission);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of TopEstateAgent method, of class EstateAgent.
     */
    @Test
    public void testTopEstateAgent() {
        System.out.println("TopEstateAgent");
        double[][] propertySales = null;
        double commission = 0.0;
        double totalSales = 0.0;
        double firstCommission = 0.0;
        double secondCommission = 0.0;
        double sum1 = 0.0;
        double sum2 = 0.0;
        EstateAgent.TopEstateAgent(propertySales, commission, totalSales, firstCommission, secondCommission, sum1, sum2);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
