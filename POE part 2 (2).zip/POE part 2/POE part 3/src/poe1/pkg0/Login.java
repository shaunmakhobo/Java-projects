
package poe1.pkg0;

import java.awt.Checkbox;
import javax.swing.JOptionPane;


public class Login {
    //Checking if username meet requirements
    public static boolean checkUserName(String username){
       if (username.length() <= 5 && username.contains("_") )
       {
    JOptionPane.showMessageDialog(null, "Username successfully captured");
         return true;
         
       }else{
    JOptionPane.showMessageDialog(null, "Username incorrectly formated " + " please Ensure that your username contains an underscore " + 
                     "and is not longer than 5 characters in length ");
                  return false;
             
         
                  
 }

   
   }


   public static boolean checkPasswordComplexity(String pass){
    
       //Declaration
   String specialChars = "(.*[@,#,$,%].*)";
   String BigL = "(.*[A-Z].*)";
   String SmolL = "(.*[a-z].*)";
   String num = "(.*[0-9].*)";

   //Checking if password meet requirements
   if ( pass.length() >= 8
       && pass.matches(specialChars)
       && pass.matches(BigL)
       && pass.matches(SmolL)
       && pass.matches(num))
       
       

{
 JOptionPane.showMessageDialog(null, "password successfully captured");
   return true;
 
}
   else 
   {
  JOptionPane.showMessageDialog(null, "Password is not correctly formatted please ensure that "
          + " the password contains at least 8 characters, a capital letter, a number and a special character.");
  return false;      
 
}


  }

public static String registerUser (boolean checkpassword, boolean checkUsername){
  if (checkUsername==true && checkpassword==true ){
       return "The two conditions have been met and the user has been resgistered successfully";
     } else {
      return "The username or password is incorrectly formated";
  }
}
public static boolean loginUser(String username, String fullNM, String pass){
    String Usern = JOptionPane.showInputDialog("Kindly Login with registered Username");
    String PassWd = JOptionPane.showInputDialog("Kindly Login with registered Password");

    
if (Usern.equals(username) && PassWd.equals(pass)){
    return true;
   
    } 
else 
    {
    return false;
    }
}
public static String returnLoginStatus(boolean checklLogin, String fullNM){


   String a = "Welcome " + fullNM + " it is great to see you again";
   String b = "Username or password incorrect please try again";
   
    
     if (/*Username.equals(Username)&& Password.equals(Password)*/checklLogin == true)
     {
        JOptionPane.showMessageDialog(null, "A successful login");
               
        return a;
     } 
     else 
     {
        JOptionPane.showMessageDialog(null, "A failed login");
        return b;
     }    
}
 
}