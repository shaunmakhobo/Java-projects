package poe1.pkg0;


import javax.swing.JOptionPane;
import java.util.Scanner;
import java.util.ArrayList;
import poe1.pkg0.EasyKanban;
import poe1.pkg0.Login;


public class POE10 {

    
    public static void main(String[] args){
        
        
       //Declarations
        String username = "";
        String firstNM, LastNM;
        String pass = "";
        String fullNM;
        boolean loginStatus = false;
        boolean input = true;
        
        //Prompting user's details
       firstNM = JOptionPane.showInputDialog("Required to input first name");
       LastNM = JOptionPane.showInputDialog("Required to input Last Name");
         
        fullNM = firstNM + " " + LastNM;
        
       //Ensuring that user met requirements of username and password creation 
      while(input)
      {
          
          username = JOptionPane.showInputDialog("Required to input username");
         
          pass = JOptionPane.showInputDialog("Required to input Password");
          
          if(Login.checkUserName(username) == true && Login.checkPasswordComplexity(pass) == true)
          {
            input = false;
          }
          else if (Login.checkUserName(username) == false || Login.checkPasswordComplexity(pass) == false)
          {
              JOptionPane.showMessageDialog(null, "You will be required to reset your username and password acording to instructions");
              input = true;  
          }
       
      }
      
       
        //Login for user after registration by comparing with the registered information with login information
        for(int c = 1; c < 5 && loginStatus == false; c++)
         { 
             
            loginStatus = Login.loginUser(username, fullNM, pass);
        
           if(loginStatus == true)
            {
               
            JOptionPane.showMessageDialog(null, Login.returnLoginStatus(loginStatus, fullNM));
             c = 6;
            }
           else
            {
            JOptionPane.showMessageDialog(null, Login.returnLoginStatus(loginStatus, fullNM));
                    
            }
            
        }
  
        EasyKanban.showButtons();
                 
        }   
}

