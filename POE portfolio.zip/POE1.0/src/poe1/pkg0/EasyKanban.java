
package poe1.pkg0;

import java.util.ArrayList;
import javax.swing.JOptionPane;


public class EasyKanban {
     ArrayList<String> taskDetails = new ArrayList<>();
        ArrayList<Integer> taskNums = new ArrayList<>();
        String[] Option = {
        "Task done",
         "Longest task",
         "Search taskName",
         "Search Developer",
         "Delete TaskName",
         "Display Report"};
        
         ArrayList<String> Task_Names = new ArrayList<>();
      ArrayList<String> Task_Description = new ArrayList<>();
      ArrayList<Integer> Task_Numbers = new ArrayList<>();
      ArrayList<Integer> Task_Duration = new ArrayList<>();
      ArrayList<String> Task_Status = new ArrayList<>();
      ArrayList<String> Task_ID = new ArrayList<>();
      ArrayList<String> developerDetails = new ArrayList<>(); 
        
        
    public static void showButtons(){
        JOptionPane.showMessageDialog(null, "Welcome to EasyKanban");
        String Task_Numbers;
        int Numtask;
        String TaskName = null;
        String Task_Description = null;
        String Developer_Details = null;
        String Task_Duration;
        int DurationTask = 0;
        String devlName = null;
        String statusTask;
        int totalHours = 0;
        String[] status = {"Done",
         "Doing",
         "To Do"};
        String taskID = null;
        EasyKanban execute = new EasyKanban();
       
       
     Object[] options = {"Add task",
         "Show report",
         "Quit"};
     int choice =
   JOptionPane.showOptionDialog(null, "Choose an Option:", "Button example", 
           JOptionPane.YES_NO_CANCEL_OPTION,
           JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
     
     //Handle the user's choice 
     while (choice != 2)
             {
     switch (choice){
         case  JOptionPane.YES_OPTION  :  
          Task_Numbers = JOptionPane.showInputDialog(null, "Specify number tasks you want", "First Option", JOptionPane.QUESTION_MESSAGE);
           Numtask = Integer.parseInt(Task_Numbers);
          for (int x = 0; x < Numtask; ++x)
          {
             TaskName = JOptionPane.showInputDialog("Input TaskName");
             Task_Description = JOptionPane.showInputDialog("Input Task Description");
             Task_Duration = JOptionPane.showInputDialog(null, "Input duration in hours");
             DurationTask = Integer.parseInt(Task_Duration);
             
             while (EasyKanban.checkTaskDescription(Task_Description) == false )
             { 
               JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters", "Add Task, choice", JOptionPane.ERROR_MESSAGE);
             Task_Description = JOptionPane.showInputDialog(null, "What is the task description for task" + Numtask + ":", "Add Tasks", JOptionPane.QUESTION_MESSAGE);
            
             }
             Developer_Details = JOptionPane.showInputDialog(null, "Input first name and Lastname");
            taskID = TaskID(Task_Numbers, TaskName, Developer_Details);
            statusTask = Tststatus(status, choice);
           
            JOptionPane.showMessageDialog(null, printTaskDetails(TaskName, Numtask, Task_Description, DurationTask, TaskID(Task_Numbers, TaskName, Developer_Details), statusTask));
            totalHours = totalHours + DurationTask;
            
            execute.Storage(totalHours, TaskName, x, Task_Description, DurationTask, taskID, statusTask, Developer_Details);
          }
          JOptionPane.showMessageDialog(null, "The total number of hours: " + returnTotalHours(totalHours));
          
         break;
         
         case  JOptionPane.NO_OPTION:
          // JOptionPane.showMessageDialog(null, "Coming soon");
          // execute.Room704();
           switch (execute.selectButtons()) {
               case 0: 
               execute.Task_done();
               break;
               case 1:
               execute.Longest_task(); 
               break;
               case 2:
                   execute.scout_TaskName();
                   break;
               case 3:
                   execute.Scout_Developer();
                   break;
               case 4:
                   execute.Delete();
                   break;
               case 5:
                   execute.displayAll();
                   break;
               default:
                   JOptionPane.showMessageDialog(null, "Invalid Choice", "Task Menu", JOptionPane.ERROR_MESSAGE);
           }
           //execute.Task_done();
         break;
         
         case  JOptionPane.CANCEL_OPTION:
       
         break;
         default: 
     }
     
        choice =
   JOptionPane.showOptionDialog(null, "Choose an Option:", "Button example", 
           JOptionPane.YES_NO_CANCEL_OPTION,
           JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
     }
    }
    public static String TaskID( String Task_Numbers, String Task_Name, String devlName){
        String TaskID = null;
        
        int NumTask;
        NumTask = Integer.parseInt(Task_Numbers);
     
        StringBuilder ID = new StringBuilder(Task_Name);
        ID.setLength(2);
        ID.append(":");
        ID.append(Task_Numbers);
        ID.append(":");
     for (int x = 0;x < devlName.length();++x)
     {  
         if (devlName.charAt(x) == ' ')
         {
         ID.append(devlName.substring(x-3, x));
         String toUpperCase = ID.toString();
         TaskID = toUpperCase.toUpperCase();
         x = devlName.length();
         }
     }
     return TaskID;
    }
    public static boolean checkTaskDescription(String Task_Description ) {
    if (Task_Description.length() < 50){
        JOptionPane.showMessageDialog(null, "Task succesfully captured");
        return true;
    }
    else {
       JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters"); 
    return false;
    }
    }
   
    public static String Tststatus(String[] tskStatus, int option) {
        String TempStatus;
    option = JOptionPane.showOptionDialog(null, "Please select an Option", "Add Task", 0, 3, null, tskStatus , tskStatus[0]);
             
     switch (option){
         case 0:  
          TempStatus = tskStatus[0];
         break;
         
           case 1:
           TempStatus = tskStatus[1];
         break;
         
         case 2:
          TempStatus = tskStatus[2];
         break;
         default:
             TempStatus = "";
     }
      return TempStatus;
     
    }
    public static String printTaskDetails(String tskName, int tskNum, String taskDescription, int TaskDuration, String TaskID, String TaskStatus) 
        {
            return tskName +"\n"+ tskNum +"\n"+ taskDescription +"\n"+TaskDuration+"hrs"+"\n"+ TaskID+"\n"+ TaskStatus;
        
        } 
        
        public static int returnTotalHours(int totalHours) {
           
           return totalHours;
        }
        public int selectButtons(){
        //JOptionPane.showOptionDialog(null, "Select option of your choice", "Option", JOptionPane.INFORMATION_MESSAGE, null, Option, Option[0]);
        int option2;
        return JOptionPane.showOptionDialog(null, "Select option of your choice", "Option", 0, JOptionPane.INFORMATION_MESSAGE, null, Option, Option[0]);
        
        }
     public void Storage(int totalHours,
        String tskName,
        int tskNum,
        String taskDescription,
        int TaskDuration,
        String TaskID,
        String TaskStatus,
        String Developer_Details){
      
         Task_Names.add(tskName);
         Task_Description.add(taskDescription);
         Task_Numbers.add(tskNum);
         Task_Duration.add(TaskDuration);
         Task_Status.add(TaskStatus);
         Task_ID.add(TaskID);
         developerDetails.add(Developer_Details);
         
        System.out.println("Tasks were saved");
        //JOptionPane.showMessageDialog(null, Card.get(0));
         
     } 
     public void Task_done(){
         int count = 0;
    // JOptionPane.showMessageDialog(null, Card.get(0));
     for (int i = 0; i < Task_Status.size(); i++){
         System.out.println(Task_Status.get(i));
       if ( Task_Status.get(i).contains("Done")){
       JOptionPane.showMessageDialog(null, Task_Names.get(i) +"\n"+ developerDetails.get(i) +"\n"+  Task_Duration.get(i) + "hour(s)");
       break;
     } else {
        JOptionPane.showMessageDialog(null, "No Task done", "Task done", JOptionPane.ERROR_MESSAGE);
     
     // count = i;
               }
    
             }
     
     }
    public void Longest_task() {
       
      int Largest = Task_Duration.get(0);
      int Element = 0;
     for (int j = 0; j < Task_Duration.size(); j++){
     if ( Task_Duration.get(j) > Largest){
      Largest = Task_Duration.get(j);
      Element = j;
    }
     }
      JOptionPane.showMessageDialog(null, developerDetails.get(Element) +"\n"+ Largest + "hour(s)");
        //System.out.println("Long");
}
  public void Delete() {
  
    int i = 0;
    String Temporary_DevDetails;
    String search = JOptionPane.showInputDialog(null, "Which task Name would you like to delete: ", "searching developer", JOptionPane.QUESTION_MESSAGE);
    
    for (int Element = 0; Element < Task_Names.size(); Element++) {
      Temporary_DevDetails = Task_Names.get(Element).toLowerCase();
      if (Temporary_DevDetails.contains(search.toLowerCase()))
      {
         Task_Names.remove(i);
         Task_Numbers.remove(i);
         Task_Description.remove(i);
         Task_Duration.remove(i);
         Task_Status.remove(i);
         Task_ID.remove(i);
         developerDetails.remove(i);
        //JOptionPane.showMessageDialog(null, Task_Names.get(i) +"\n"+ Task_Status.get(i), search, JOptionPane.INFORMATION_MESSAGE);
      }
      else
      {
          ++i;
      }
      
    }
    if (i == Task_Names.size())
        JOptionPane.showMessageDialog(null, "Task is removed", "Delete Task", JOptionPane.INFORMATION_MESSAGE);
  }  
  
   public void displayAll(){
     for(int i = 0; i < Task_Names.size(); ++i){
         System.out.println("This is the size of the array " + Task_Names.size());
         System.out.println("The index is: " + i);
        JOptionPane.showMessageDialog(null, Task_Status.get(i) +"\n"+ developerDetails.get(i) +"\n"+  Task_Names.get(i) +"\n"+ Task_Description.get(i) +"\n"+ Task_ID.get(i) +"\n"+ Task_Duration.get(i) + "hour(s)", "Display all tasks", JOptionPane.INFORMATION_MESSAGE);
     }
   }
   public void scout_TaskName(){
    int count = 0;
    String Temporary_TaskName;
    String searchName = JOptionPane.showInputDialog(null, "Which Task Name would you like to search: ", "searching TaskName", JOptionPane.QUESTION_MESSAGE);
    
    for (int Element = 0; Element < Task_Names.size(); ++Element)
    {
    Temporary_TaskName = Task_Names.get(count).toLowerCase();
    if (Temporary_TaskName.contentEquals(searchName.toLowerCase()))
     JOptionPane.showMessageDialog(null, Task_Names.get(count) +"\n"+ developerDetails.get(count) +"\n"+ Task_Status.get(count), "Searching Task Name", JOptionPane.INFORMATION_MESSAGE);
    
    else 
    {
       ++count;
    }
    }
    if (count == developerDetails.size())
        JOptionPane.showMessageDialog(null, "Results where not found ", "Searching Task Name", JOptionPane.ERROR_MESSAGE);
   }
   public void Scout_Developer(){
    
       int count = 0;
       String Temporary_DeveloperDetails;
       String search = JOptionPane.showInputDialog(null, "Which developer would you like to search: ", "searching developer", JOptionPane.QUESTION_MESSAGE);
       
       for (int Element = 0; Element < developerDetails.size(); ++Element)
       {
        Temporary_DeveloperDetails = developerDetails.get(Element).toLowerCase();
        if (Temporary_DeveloperDetails.contains(search.toLowerCase()))
        {
          JOptionPane.showMessageDialog(null, Task_Names.get(Element) +"\n"+ Task_Status.get(Element), search, JOptionPane.INFORMATION_MESSAGE);
        }
       }
   }
} 